const express = require("express");
const cors = require("cors");

const app = express();
app.use(express.json());
app.use(cors()); // Allow frontend requests

// Function to rotate the string based on a given date (d)
function rotateString(str, d) {
  d = d % str.length;
  return str.slice(d) + str.slice(0, d);
}

// API endpoint to handle rotation logic
app.post("/rotate", (req, res) => {
  const { date } = req.body;
  const originalName = "EETANMAY"; // The scrambled name
  const rotatedName = rotateString(originalName, date);
  res.json({ rotatedName });
});

// Start the server
const PORT = 5000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));
